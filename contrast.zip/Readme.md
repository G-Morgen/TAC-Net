# 项目中文名
TASS-NET
# 作者
黄超
# 项目简介
## 1. 功能
帧级视频异常检测
## 2. 性能
USCD Ped2     auc=98.18%
Avenue        auc =88.88%
1.3 fps
## 3. 评估指标
AUC
## 4. 使用数据集
1.USCD Ped2    
2.Avenue

# 运行环境与依赖
代码运行的环境与依赖。如下所示：

|类别|名称|版本|
|-----|-----|-----|
|语言|python|3.7.9|
|os|ubuntu|16.04|
|深度学习框架|pytorch|1.6.0|
||numpy|1.19.2|
||opencv-contrib-python|4.4.0.46|


 

# 输入与输出
代码的输入与输出。如下所示：

|名称|说明|
|-----|-----|
|输入|RGB图像。大小为256X256（宽x高）|
|输出|异常分值0~1 越接近0表示越有可能是异常|

# 运行方式
代码文件是/disk2/shangguoqian/contrast
## Train
```Shell
#Default
CUDA_VISIBLE_DEVICES=1 python train.py --dataset=ped2 --batch_size=2 --iters=40000 #ped2
CUDA_VISIBLE_DEVICES=1 python train.py --dataset=avenue --batch_size=2 --iters=40000 #avenue
```

## Evalution
```Shell
# Validate with a trained model.
CUDA_VISIBLE_DEVICES=0 python evaluate.py --dataset=ped2 --trained_model=ped2_25000.pth #ped2
CUDA_VISIBLE_DEVICES=0 python evaluate.py --dataset=avenue --trained_model=avenue_28000.pth #avenue
```