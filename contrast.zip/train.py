from evaluate import val
from config import update_config
from models.resnet3dnogru import generate_model
import Dataset
from losses import *
from utils import *
import random
import argparse
from torch.utils.data import DataLoader
import datetime
import time
import torch
import numpy as np
import cv2
from glob import glob
from tensorboardX import SummaryWriter
import sys
import os

seed = 1234
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.cuda.manual_seed_all(seed)

parser = argparse.ArgumentParser(description='Anomaly Prediction')
parser.add_argument('--batch_size', default=2, type=int)
parser.add_argument('--dataset', default='avenue', type=str,
                    help='The name of the dataset to train.')
parser.add_argument('--iters', default=40000, type=int,
                    help='The total iteration number.')
parser.add_argument('--resume', default=None, type=str,
                    help='The pre-trained model to resume training with, pass \'latest\' or the model name.')
parser.add_argument('--save_interval', default=1000, type=int,
                    help='Save the model every [save_interval] iterations.')
parser.add_argument('--val_interval', default=1000, type=int,
                    help='Evaluate the model every [val_interval] iterations, pass -1 to disable.')
parser.add_argument('--show_flow', default=False, action='store_true',
                    help='If True, the first batch of ground truth optic flow could be visualized and saved.')


args = parser.parse_args()


class Logger(object):
    def __init__(self, fileN='Default.log'):
        self.terminal = sys.stdout
        self.log = open(fileN, 'a')

    def write(self, message):
        '''print实际相当于sys.stdout.write'''
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        pass


sys.stdout = Logger('print.txt')
train_cfg = update_config(args, mode='train')  
train_cfg.print_cfg()


generator = generate_model(10)


generator = nn.DataParallel(generator).cuda()

optimizer_G = torch.optim.AdamW(filter(lambda p: p.requires_grad, generator.parameters(
)), lr=train_cfg.g_lr, weight_decay=0.0001)  
#optimizer_D = torch.optim.Adam(discriminator.parameters(), lr=train_cfg.d_lr)


writer = SummaryWriter(
    f'tensorboard_log/{train_cfg.dataset}_bs{train_cfg.batch_size}')

if train_cfg.resume:
    generator.load_state_dict(torch.load(train_cfg.resume)['net_g'])

    optimizer_G.load_state_dict(torch.load(train_cfg.resume)['optimizer_g'])

    print(f'Pre-trained generator has been loaded.\n')
    # print("继续训练的时候模型内部队列的指针为:",generator.module.queue_ptr)
else:
    generator.apply(weights_init_normal)

    print('Generator is going to be trained from scratch.\n')
    # print("初始化的时候模型内部队列的指针为:",generator.module.queue_ptr)

gradient_loss = Gradient_Loss(3).cuda()

intensity_loss = Intensity_Loss().cuda()

pretask_loss = nn.CrossEntropyLoss().cuda()

contrastive_loss = nn.CrossEntropyLoss().cuda()

train_dataset = Dataset.train_dataset(train_cfg)

# Remember to set drop_last=True, because we need to use 8 frames to predict one frame.
train_dataloader = DataLoader(dataset=train_dataset, batch_size=train_cfg.batch_size,
                              shuffle=True, num_workers=4, drop_last=True)


start_iter = int(train_cfg.resume.split(
    '_')[-1].split('.')[0]+1) if train_cfg.resume else 0
freeze_iter = 100
training = True
generator = generator.train()
# discriminator = discriminator.train()

try:
    step = start_iter
    max_auc = 0.85
    max_iter = -1
    # pre1,pre2,pre3=None,None,None
    while training:

        
        for indice, clips, flow_strs in train_dataloader:

            
            input_frames = clips[:, 0:24, :, :]
            input_frames = input_frames.view(train_cfg.batch_size, 8, 3, 256, 256).permute(
                0, 2, 1, 3, 4).cuda() 
            target_frame = clips[:, 24:27, :, :].cuda()

            # input_last = input_frames[:, 21:24, :, :].cuda()  # use for flow_loss

            # pop() the used frame index, this can't work in train_dataset.__getitem__ because of multiprocessing.
            for index in indice:
                train_dataset.all_seqs[index].pop()
                if len(train_dataset.all_seqs[index]) == 0:
                    # train_dataset.all_seqs[index] = list(range(len(train_dataset.videos[index]) - 4))
                    train_dataset.all_seqs[index] = list(
                        range(len(train_dataset.videos[index]) - 8))
                    random.shuffle(train_dataset.all_seqs[index])

            # G_frame= generator(input_frames) 
            G_frame, y, label_y, z, label_z, y_features, z_features = generator(
                input_frames, 0)  

            
            # positive logits: bsx1
            T = 0.07
            l_pos_y = torch.einsum(
                'bf,bf->b', [y_features, z_features]).unsqueeze(-1)  # bs*1

            l_neg_y = torch.einsum(
                'bf,fk->bk', [y_features, generator.module.queue.clone().detach()])  # bs*k
            logits_y = torch.cat([l_pos_y, l_neg_y], dim=1)  # bs*(k+1)
            # apply temperature
            logits_y /= T

            contra_label = torch.zeros(
                train_cfg.batch_size, dtype=torch.long).cuda()

            with torch.no_grad():  # no gradient to encoder 2(k)

                # gather keys before updating queue
                

                ptr = int(generator.module.queue_ptr)
                
                assert generator.module.K % train_cfg.batch_size == 0  # for simplicity

                
                generator.module.queue[:, ptr:ptr +
                                       train_cfg.batch_size] = z_features.T
                # move pointer
                ptr = (ptr + train_cfg.batch_size) % generator.module.K

                generator.module.queue_ptr[0] = ptr
                

            contrast_l = contrastive_loss(logits_y, contra_label)

            inte_l = intensity_loss(G_frame, target_frame)
            grad_l = gradient_loss(G_frame, target_frame)
            task_y_l = pretask_loss(y, label_y.long())
            task_z_l = pretask_loss(z, label_z.long())

            G_l_t = 1. * inte_l + 1. * grad_l + 0.0001*contrast_l+task_y_l+task_z_l

            optimizer_G.zero_grad()
            G_l_t.backward()
            # optimizer_D.step()
            optimizer_G.step()

            torch.cuda.synchronize()
            time_end = time.time()
            if step > start_iter:  # This doesn't include the testing time during training.
                iter_t = time_end - temp
            temp = time_end

            if step != start_iter:
                if step >= freeze_iter:
                    for para in generator.module.avgpool_pro1.parameters():
                        para.requires_grad = False
                    for para in generator.module.mlp1.parameters():
                        para.requires_grad = False

                if step % 100 == 0:
                    time_remain = (train_cfg.iters - step) * iter_t
                    eta = str(datetime.timedelta(
                        seconds=time_remain)).split('.')[0]
                    psnr = psnr_error(G_frame, target_frame)
                    lr_g = optimizer_G.param_groups[0]['lr']

                    print(f"[{step}]  inte_l: {inte_l:.3f} | grad_l: {grad_l:.3f} | task_y_l: {task_y_l:.3f} | task_z_l: {task_z_l:.3f} |contrast_l: {contrast_l:.3f} |"
                          f"G_l_total: {G_l_t:.3f} | psnr: {psnr:.3f} ")

                    save_G_frame = ((G_frame[0] + 1) / 2)
                    save_G_frame = save_G_frame.cpu().detach()[(2, 1, 0), ...]

                    save_target = ((target_frame[0] + 1) / 2)
                    save_target = save_target.cpu().detach()[(2, 1, 0), ...]

                    writer.add_scalar('psnr/train_psnr',
                                      psnr, global_step=step)
                    writer.add_scalar('total_loss/g_loss_total',
                                      G_l_t, global_step=step)

                    writer.add_scalar('G_loss_total/inte_loss',
                                      inte_l, global_step=step)
                    writer.add_scalar('G_loss_total/grad_loss',
                                      grad_l, global_step=step)

                if step % train_cfg.val_interval == 0:
                    auc_psnr_contrast_gaussian = val(
                        train_cfg, model=generator)
                    if auc_psnr_contrast_gaussian > max_auc:
                        max_auc = auc_psnr_contrast_gaussian
                        max_iter = step
                        model_dict = {'net_g': generator.state_dict(
                        ), 'optimizer_g': optimizer_G.state_dict()}
                        torch.save(
                            model_dict, f'weights/{train_cfg.dataset}_{step}.pth')
                    elif step % 20000 == 0:
                        model_dict = {'net_g': generator.state_dict(
                        ), 'optimizer_g': optimizer_G.state_dict()}

                        torch.save(
                            model_dict, f'weights/{train_cfg.dataset}_{step}.pth')

                    print('iter '+str(step)+'auc '+str(auc_psnr_contrast_gaussian) +
                          'max_auc: '+str(max_auc) + '  when step: '+str(max_iter))

                    writer.add_scalar('results/auc_psnr_contrast_gaussian',
                                      auc_psnr_contrast_gaussian, global_step=step)

                    generator.train()

            step += 1
            if step > train_cfg.iters:
                training = False
                model_dict = {'net_g': generator.state_dict(
                ), 'optimizer_g': optimizer_G.state_dict()}
                # model_dict = {'net_g': generator.state_dict(), 'optimizer_g': optimizer_G.state_dict(),
                #               'net_d': discriminator.state_dict(), 'optimizer_d': optimizer_D.state_dict()}
                torch.save(
                    model_dict, f'weights/latest_{train_cfg.dataset}_{step}.pth')
                break

except KeyboardInterrupt:
    print(
        f'\nStop early, model saved: \'latest_{train_cfg.dataset}_{step}.pth\'.\n')

    if glob(f'weights/latest*'):
        os.remove(glob(f'weights/latest*')[0])
    model_dict = {'net_g': generator.state_dict(
    ), 'optimizer_g': optimizer_G.state_dict()}
    # model_dict = {'net_g': generator.state_dict(), 'optimizer_g': optimizer_G.state_dict(),
    #               'net_d': discriminator.state_dict(), 'optimizer_d': optimizer_D.state_dict()}
    torch.save(model_dict, f'weights/latest_{train_cfg.dataset}_{step}.pth')
