# 专门为了shanghaitech写的，把train/videos里面的.avi都转成.jpg
from pathlib import Path
import time
import ffmpeg



def avi_jpg(videospath,outputpath)
	Path(outputpath).mkdir(parents=True, exist_ok=True)
	rootdir = Path(videospath)
	videos = [str(f) for f in rootdir.glob('**/*.avi')]
	for video in videos:
		videoname = video.split("/")[-1].split(".")[0]
		jpgpath = outputpath+ '/{}/'.format(videoname)
		startime = time.time()
		print("Generating for {0}".format(video))
		Path(jpgpath).mkdir(parents=True, exist_ok=True)
		ffmpeg.input(video).output('{}%05d.jpg'.format(jpgpath),start_number=0).global_args('-loglevel', 'quiet').run()
		print("Preprocessing done..")
		print("done in {0}.".format(time.time() - startime))

if __name__ == '__main__': 
	avi_jpg('/disk3/huangchao/download/future_data_root/shanghaitech/training/videos/','/disk3/shangguoqian/download/future_data_root/shanghaitech/output_jpg')
