from scipy.ndimage import gaussian_filter1d
from models.resnet3dnogru import generate_model
import Dataset

from utils import psnr_error
from Dataset import Label_loader
from config import update_config
import torch.nn as nn
import matplotlib.pyplot as plt
from sklearn import metrics
import io
from PIL import Image
import cv2
import argparse
import torch
import time
import numpy as np
import os

seed = 1234
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.cuda.manual_seed_all(seed)

# from models.unet import UNet
# from models.new_prediction import Prediction
# from models.resnet3d import generate_model

parser = argparse.ArgumentParser(description='Anomaly Prediction')
parser.add_argument('--dataset', default='avenue', type=str,
                    help='The name of the dataset to train.')
parser.add_argument('--trained_model', default=None, type=str,
                    help='The pre-trained model to evaluate.')
parser.add_argument('--show_curve', action='store_true',
                    help='Show and save the psnr curve real-timely, this drops fps.')  
parser.add_argument('--show_heatmap', action='store_true',
                    help='Show and save the difference heatmap real-timely, this drops fps.')  


def min_max_normalize(arr):
    max_a = np.max(arr)
    min_a = np.min(arr)
    if min_a == max_a:
        return np.ones(shape=arr.shape)
    return (arr - min_a) / (max_a - min_a)


def val(cfg, model=None):
    if model:  # This is for testing during training.
        generator = model
        generator.eval()
    else:
        # generator = UNet(input_channels=12, output_channel=3).cuda().eval()
        #generator = UNet(input_channels=24, output_channel=3).cuda().eval()
        # generator = Prediction(in_channels=24, out_channels=3).cuda().eval()
        generator = generate_model(10)
        generator = nn.DataParallel(generator).cuda().eval()
        generator.load_state_dict(torch.load(
            'weights/' + cfg.trained_model)['net_g'])
        print(
            f'The pre-trained generator has been loaded from \'weights/{cfg.trained_model}\'.\n')

    video_folders = os.listdir(cfg.test_data)
    video_folders.sort()
    video_folders = [os.path.join(cfg.test_data, aa)
                     for aa in video_folders]  

    fps = 0

    # 里面包含每个测试文件夹的psnr+pretask1_loss+pretask2_loss+contrast列表[[testvideo0],[testvideo1]...]

    regularity_psnr_contrast = []

    if not model:
        if cfg.show_curve:
            fig = plt.figure("Image")
            manager = plt.get_current_fig_manager()
            manager.window.setGeometry(550, 200, 600, 500)
            # This works for QT backend, for other backends, check this ⬃⬃⬃.
            # https://stackoverflow.com/questions/7449585/how-do-you-set-the-absolute-position-of-figure-windows-with-matplotlib
            plt.xlabel('frames')
            plt.ylabel('psnr')
            plt.title('psnr curve')
            plt.grid(ls='--')

            cv2.namedWindow('target frames', cv2.WINDOW_NORMAL)
            cv2.resizeWindow('target frames', 384, 384)
            cv2.moveWindow("target frames", 100, 100)

        if cfg.show_heatmap:
            cv2.namedWindow('difference map', cv2.WINDOW_NORMAL)
            cv2.resizeWindow('difference map', 384, 384)
            cv2.moveWindow('difference map', 100, 550)

    with torch.no_grad():
        for i, folder in enumerate(video_folders):  
            dataset = Dataset.test_dataset(cfg, folder)

            if not model:
                name = folder.split('/')[-1]
                fourcc = cv2.VideoWriter_fourcc('X', 'V', 'I', 'D')

                if cfg.show_curve:
                    video_writer = cv2.VideoWriter(
                        f'results/{name}_video.avi', fourcc, 30, cfg.img_size)
                    curve_writer = cv2.VideoWriter(
                        f'results/{name}_curve.avi', fourcc, 30, (600, 430))

                    js = []
                    plt.clf()
                    ax = plt.axes(xlim=(0, len(dataset)), ylim=(30, 45))
                    line, = ax.plot([], [], '-b')

                if cfg.show_heatmap:
                    heatmap_writer = cv2.VideoWriter(
                        f'results/{name}_heatmap.avi', fourcc, 30, cfg.img_size)

            psnrs = []  # 某个测试文件夹的psnr，后面被塞到regularity_group里面

            contrast = []
            contrast_4 = []
            contrast_5 = []
            pretask1 = []  
            pretask2 = []  
            pretask1_4 = []
            pretask1_5 = []
            pretask2_4 = []
            pretask2_5 = []
            for j, clip in enumerate(dataset):
                # input_np = clip[0:12, :, :]
                # target_np = clip[12:15, :, :]
                input_np = clip[0:24, :, :]
                target_np = clip[24:27, :, :]
                # input_frames = torch.from_numpy(input_np).unsqueeze(0).cuda() 

                input_frames = torch.from_numpy(
                    input_np).unsqueeze(0)  
                input_frames = input_frames.view(1, 8, 3, 256, 256).permute(
                    0, 2, 1, 3, 4).cuda()  
                target_frame = torch.from_numpy(target_np).unsqueeze(0).cuda()

                G_frame, y, label_y, z, label_z, y_features, z_features = generator(
                    input_frames, 0)  

                test_psnr = psnr_error(G_frame, target_frame).cpu(
                ).detach().numpy()  

                # tensor(batchsize)
                sim = torch.einsum(
                    'bf,bf->b', [z_features, y_features])  

                if j < len(dataset)-5:
                    psnrs.append(float(test_psnr))

                pretask1_probability = nn.functional.softmax(
                    y)[:, 0].cpu().detach().numpy()  # [bs,classes]-->[bs,1]
                pretask2_probability = nn.functional.softmax(
                    z)[:, 0].cpu().detach().numpy()  # [bs,classes]-->[bs,1]

                if j > 3 and j < len(dataset)-1:  # 2
                    contrast_5.append(float(sim))

                    pretask1_5.append(float(pretask1_probability))
                    pretask2_5.append(float(pretask2_probability))

                if j > 4:
                    contrast_4.append(float(sim))

                    pretask1_4.append(float(pretask1_probability))
                    pretask2_4.append(float(pretask2_probability))

                torch.cuda.synchronize()
                end = time.time()
                if j > 1:  # Compute fps by calculating the time used in one completed iteration, this is more accurate.
                    fps = 1 / (end - temp)
                temp = end
                print(
                    f'\rDetecting: [{i + 1:02d}] {j + 1}/{len(dataset)}, {fps:.2f} fps.', end='')

            contrast = np.array(contrast_4)+np.array(contrast_5)

            pretask1 = np.array(pretask1_4)+np.array(pretask1_5)  # 3
            pretask2 = np.array(pretask2_4)+np.array(pretask2_5)
            pretask1 = np.array(pretask1)
            pretask2 = np.array(pretask2)

            psnrs = min_max_normalize(np.array(psnrs))

            contrast = min_max_normalize(np.array(contrast))

            pretask1 = min_max_normalize(pretask1)
            pretask2 = min_max_normalize(pretask2)

            regularity_psnr_contrast.append(
                1.*psnrs+0.01*contrast+0.01*(pretask1+pretask2))

            if not model:
                if cfg.show_curve:
                    video_writer.release()
                    curve_writer.release()
                if cfg.show_heatmap:
                    heatmap_writer.release()

    # print('\nAll frames were detected, begin to compute AUC.')

    gt_loader = Label_loader(cfg, video_folders)  # Get gt labels.
    gt = gt_loader()

    # assert len(psnr_group) == len(gt), f'Ground truth has {len(gt)} videos, but got {len(psnr_group)} detected videos.'
    assert len(regularity_psnr_contrast) == len(
        gt), f'Ground truth has {len(gt)} videos, but got {len(regularity_psnr_contrast)} detected videos.'
    scores_psnr_contrast = np.array([], dtype=np.float32)

    labels = np.array([], dtype=np.int8)
    for i in range(len(regularity_psnr_contrast)):
        distance_psnr_contrast = regularity_psnr_contrast[i]
        # distance = (distance - min) / (max - min)
        distance_psnr_contrast -= min(distance_psnr_contrast)
        distance_psnr_contrast /= max(distance_psnr_contrast)

        scores_psnr_contrast = np.concatenate(
            (scores_psnr_contrast, distance_psnr_contrast), axis=0)

        # Exclude the first 8 unpredictable frames in gt. #4
        labels = np.concatenate((labels, gt[i][8:len(gt[i])-5]), axis=0)
    if cfg.dataset == "avenue":
        scores_psnr_contrast_gaussian = gaussian_filter1d(
            scores_psnr_contrast, 12.5)
    if cfg.dataset == "ped2":
        scores_psnr_contrast_gaussian = gaussian_filter1d(
            scores_psnr_contrast, 4.2)

    assert scores_psnr_contrast_gaussian.shape == labels.shape, \
        f'Ground truth has {labels.shape[0]} frames, but got {scores_psnr_contrast_gaussian.shape[0]} detected frames.'

    fpr_psnr_contrast_gaussian, tpr_psnr_contrast_gaussian, thresholds_psnr_contrast_gaussian = metrics.roc_curve(
        labels, scores_psnr_contrast_gaussian, pos_label=0)
    auc_psnr_contrast_gaussian = metrics.auc(
        fpr_psnr_contrast_gaussian, tpr_psnr_contrast_gaussian)

    # print(f'auc_psnr_contrast_gaussian: {auc_psnr_contrast_gaussian}\n')
    print('auc '+str(auc_psnr_contrast_gaussian))
    return auc_psnr_contrast_gaussian


if __name__ == '__main__':
    args = parser.parse_args()
    test_cfg = update_config(args, mode='test')
    test_cfg.print_cfg()
    val(test_cfg)
