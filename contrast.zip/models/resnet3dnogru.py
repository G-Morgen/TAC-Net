# 把GRU改成residual3d
import random
from torch.autograd import Variable
import math
from functools import partial

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms.functional as TF

from PIL import Image
from torch.nn import init
import numpy as np
import os

seed = 1234
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)
torch.cuda.manual_seed_all(seed)


def rotate_batch(x, evaluate_bool, label=None):
    """
    This function preprocess a batch for relative patch location in a 2 dimensional space.
    :param x: array of images
    :param label: None
    :return: x as np.array of images with random rotations, label np.array with one-hot encoded label
    """
    # print("刚传入rotation的x设备是",x.device)
    # get batch size
    y = x.cpu().numpy()

    # print("y形状",y.shape)
    batch_size = y.shape[0]
    # init np array with zeros
    # label = np.zeros((batch_size, 4))
    label = np.zeros(batch_size)
    if evaluate_bool == 0:  # 要数据增强
        rotated_batch = []
        # print("label类型",type(label))
        # loop over all images with index and image

        for index, image in enumerate(y):

            rot = np.random.random_integers(4) - 1
            image = np.rot90(image, rot, (2, 3))

            rotated_batch.append(image)
            label[index] = rot
            # print("image形状和rot值分别为",image.shape,rot)
        # return images and rotation
        # print("label为",label)
        return torch.from_numpy(np.stack(rotated_batch)).cuda(), torch.from_numpy(label).cuda()
    else:
        return torch.from_numpy(y).cuda(), torch.from_numpy(label).cuda()


def reverse_batch(x, evaluate_bool, label=None):
    """
    This function preprocess a batch for relative patch location in a 2 dimensional space.
    :param x: array of images
    :param label: None
    :return: x as np.array of images with random rotations, label np.array with one-hot encoded label
    """

    # print("刚传入rotation的x设备是",x.device)
    # get batch size
    y = x.cpu().numpy()

    # print("y形状",y.shape)
    batch_size = y.shape[0]
    # init np array with zeros
    # label = np.zeros((batch_size, 4))
    label = np.zeros(batch_size)
    if evaluate_bool == 0:  # 要数据增强
        reversed_batch = []
        # print("label类型",type(label))
        # loop over all images with index and image

        for index, image in enumerate(y):  # image是指的8帧图片，不是单帧图片，这里的y是五维的
            reverse = random.randint(0, 1)
            if reverse == 1:  # 倒序
                image = np.flip(image, [1])
            reversed_batch.append(image)
            label[index] = reverse
            # print("image形状和rot值分别为",image.shape,rot)
        # return images and rotation
        # print("label为",label)
        return torch.from_numpy(np.stack(reversed_batch)).cuda(), torch.from_numpy(label).cuda()
    else:
        return torch.from_numpy(y).cuda(), torch.from_numpy(label).cuda()


def shuffle_batch(x, evaluate_bool, label=None):
    """
    This function preprocess a batch for relative patch location in a 2 dimensional space.
    :param x: array of images
    :param label: None
    :return: x as np.array of images with random rotations, label np.array with one-hot encoded label
    """

    # print("刚传入rotation的x设备是",x.device)
    # get batch size
    y = x.cpu().numpy()

    # print("y形状",y.shape)
    batch_size = y.shape[0]
    # init np array with zeros
    # label = np.zeros((batch_size, 4))
    label = np.zeros(batch_size)
    if evaluate_bool == 0:  # 要数据增强
        shuffled_batch = []
        # print("label类型",type(label))
        # loop over all images with index and image

        for index, image in enumerate(y):  # image是指的8帧图片，不是单帧图片，这里的y是五维的
            shuffle = random.randint(0, 1)
            if shuffle == 1:  # 内部随机
                image = np.transpose(image, (1, 0, 2, 3))  # c,t,h,w-->t,c,h,w
                np.random.shuffle(image)  # 在t维度shuffle
                image = np.transpose(image, (1, 0, 2, 3))  # t,c,h,w-->c,t,h,w
            shuffled_batch.append(image)
            label[index] = shuffle
            # print("image形状和rot值分别为",image.shape,rot)
            # return images and rotation
            # print("label为",label)
        return torch.from_numpy(np.stack(shuffled_batch)).cuda(), torch.from_numpy(label).cuda()
    else:
        return torch.from_numpy(y).cuda(), torch.from_numpy(label).cuda()

# 专门为变速任务设置了一个样本提取器 speed_train_dataset，在Datasrt.py中


def get_inplanes():
    return [64, 128, 256, 512]


def conv3x3x3(in_planes, out_planes, stride=1):  # 不带gru
    return nn.Conv3d(in_planes,
                     out_planes,
                     kernel_size=3,
                     stride=stride,
                     #  stride=(1,stride,stride),
                     padding=1,
                     bias=False)


def conv1x1x1(in_planes, out_planes, stride=1):
    return nn.Conv3d(in_planes,
                     out_planes,
                     kernel_size=1,
                     stride=stride,
                     #  stride=(1,stride,stride),
                     bias=False)


class BasicBlock(nn.Module):

    def __init__(self, in_planes, planes, stride=1, downsample=None):
        super().__init__()

        self.conv1 = conv3x3x3(in_planes, planes, stride)
        self.bn1 = nn.BatchNorm3d(planes)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = conv3x3x3(planes, planes)
        self.bn2 = nn.BatchNorm3d(planes)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.downsample is not None:
            residual = self.downsample(x)
        out += residual
        out = self.relu(out)

        return out


class NOGru(nn.Module):

    def __init__(self, in_planes, planes, stride=1):
        super().__init__()

        self.conv1 = nn.Conv3d(in_planes,
                               planes,
                               kernel_size=3,
                               stride=(stride, 1, 1),
                               padding=1,
                               bias=False)
        self.bn1 = nn.BatchNorm3d(planes)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = conv3x3x3(planes, planes)
        self.bn2 = nn.BatchNorm3d(planes)
        self.downsample = nn.Conv3d(in_planes,
                                    planes,
                                    kernel_size=1,
                                    stride=(stride, 1, 1),
                                    bias=False)
        self.stride = stride

    def forward(self, x):
        residual = x
        if self.stride != 1:
            residual = self.downsample(x)
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        out += residual
        out = self.relu(out)

        return out


class Bottleneck(nn.Module):

    def __init__(self, in_planes, planes, stride=1, downsample=None):
        super().__init__()

        self.conv1 = conv1x1x1(in_planes, planes)
        self.bn1 = nn.BatchNorm3d(planes)
        self.conv2 = conv3x3x3(planes, planes, stride)
        self.bn2 = nn.BatchNorm3d(planes)
        self.conv3 = conv1x1x1(planes, planes)
        self.bn3 = nn.BatchNorm3d(planes)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:  # downsample在182行定义
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out


class _NonLocalBlockND(nn.Module):  # non_local_embedded_gaussian
    def __init__(self, in_channels, inter_channels=None, dimension=3, sub_sample=True, bn_layer=True):
        """
        :param in_channels:
        :param inter_channels:
        :param dimension:
        :param sub_sample:
        :param bn_layer:
        """

        super(_NonLocalBlockND, self).__init__()

        assert dimension in [1, 2, 3]

        self.dimension = dimension
        self.sub_sample = sub_sample

        self.in_channels = in_channels
        self.inter_channels = inter_channels

        if self.inter_channels is None:
            self.inter_channels = in_channels // 2
            if self.inter_channels == 0:
                self.inter_channels = 1

        if dimension == 3:
            conv_nd = nn.Conv3d
            max_pool_layer = nn.MaxPool3d(kernel_size=(1, 2, 2))
            bn = nn.BatchNorm3d
        elif dimension == 2:
            conv_nd = nn.Conv2d
            max_pool_layer = nn.MaxPool2d(kernel_size=(2, 2))
            bn = nn.BatchNorm2d
        else:
            conv_nd = nn.Conv1d
            max_pool_layer = nn.MaxPool1d(kernel_size=(2))
            bn = nn.BatchNorm1d

        self.g = conv_nd(in_channels=self.in_channels, out_channels=self.inter_channels,
                         kernel_size=1, stride=1, padding=0)

        if bn_layer:
            self.W = nn.Sequential(
                conv_nd(in_channels=self.inter_channels, out_channels=self.in_channels,
                        kernel_size=1, stride=1, padding=0),
                bn(self.in_channels)
            )
            nn.init.constant_(self.W[1].weight, 0)
            nn.init.constant_(self.W[1].bias, 0)
        else:
            self.W = conv_nd(in_channels=self.inter_channels, out_channels=self.in_channels,
                             kernel_size=1, stride=1, padding=0)
            nn.init.constant_(self.W.weight, 0)
            nn.init.constant_(self.W.bias, 0)

        self.theta = conv_nd(in_channels=self.in_channels, out_channels=self.inter_channels,
                             kernel_size=1, stride=1, padding=0)
        self.phi = conv_nd(in_channels=self.in_channels, out_channels=self.inter_channels,
                           kernel_size=1, stride=1, padding=0)

        if sub_sample:
            self.g = nn.Sequential(self.g, max_pool_layer)
            self.phi = nn.Sequential(self.phi, max_pool_layer)

    def forward(self, x, return_nl_map=False):
        """
        :param x: (b, c, t, h, w)
        :param return_nl_map: if True return z, nl_map, else only return z.
        :return:
        """

        batch_size = x.size(0)

        g_x = self.g(x).view(batch_size, self.inter_channels, -1)
        g_x = g_x.permute(0, 2, 1)

        theta_x = self.theta(x).view(batch_size, self.inter_channels, -1)
        theta_x = theta_x.permute(0, 2, 1)
        phi_x = self.phi(x).view(batch_size, self.inter_channels, -1)
        f = torch.matmul(theta_x, phi_x)
        f_div_C = F.softmax(f, dim=-1)

        y = torch.matmul(f_div_C, g_x)
        y = y.permute(0, 2, 1).contiguous()
        y = y.view(batch_size, self.inter_channels, *x.size()[2:])
        W_y = self.W(y)
        z = W_y + x

        if return_nl_map:
            return z, f_div_C
        return z


class NONLocalBlock1D(_NonLocalBlockND):
    def __init__(self, in_channels, inter_channels=None, sub_sample=True, bn_layer=True):
        super(NONLocalBlock1D, self).__init__(in_channels,
                                              inter_channels=inter_channels,
                                              dimension=1, sub_sample=sub_sample,
                                              bn_layer=bn_layer)


class NONLocalBlock2D(_NonLocalBlockND):
    def __init__(self, in_channels, inter_channels=None, sub_sample=True, bn_layer=True):
        super(NONLocalBlock2D, self).__init__(in_channels,
                                              inter_channels=inter_channels,
                                              dimension=2, sub_sample=sub_sample,
                                              bn_layer=bn_layer,)


class NONLocalBlock3D(_NonLocalBlockND):
    def __init__(self, in_channels, inter_channels=None, sub_sample=True, bn_layer=True):
        super(NONLocalBlock3D, self).__init__(in_channels,
                                              inter_channels=inter_channels,
                                              dimension=3, sub_sample=sub_sample,
                                              bn_layer=bn_layer,)


class convGRUCell(nn.Module):
    def __init__(self, input_size, input_dim, hidden_dim, kernel_size, bias, dtype):
        """
        Initialize the ConvLSTM cell
        :param input_size: (int, int)
            Height and width of input tensor as (height, width).
        :param input_dim: int
            Number of channels of input tensor.
        :param hidden_dim: int
            Number of channels of hidden state.
        :param kernel_size: (int, int)
            Size of the convolutional kernel.
        :param bias: bool
            Whether or not to add the bias.
        :param dtype: torch.cuda.FloatTensor or torch.FloatTensor
            Whether or not to use cuda.
        """
        super(convGRUCell, self).__init__()
        self.height, self.width = input_size
        self.padding = kernel_size[0] // 2, kernel_size[1] // 2
        self.hidden_dim = hidden_dim
        self.bias = bias
        self.dtype = dtype

        self.conv_gates = nn.Conv2d(in_channels=input_dim + hidden_dim,
                                    out_channels=2*self.hidden_dim,  # for update_gate,reset_gate respectively
                                    kernel_size=kernel_size,
                                    padding=self.padding,
                                    bias=self.bias)

        self.conv_can = nn.Conv2d(in_channels=input_dim+hidden_dim,
                                  out_channels=self.hidden_dim,  # for candidate neural memory
                                  kernel_size=kernel_size,
                                  padding=self.padding,
                                  bias=self.bias)

    def init_hidden(self, batch_size):
        return (Variable(torch.zeros(batch_size, self.hidden_dim, self.height, self.width)).type(self.dtype))

    def forward(self, input_tensor, h_cur):
        """
        :param self:
        :param input_tensor: (b, c, h, w)
            input is actually the target_model
        :param h_cur: (b, c_hidden, h, w)
            current hidden and cell states respectively
        :return: h_next,
            next hidden state
        """
        combined = torch.cat([input_tensor, h_cur], dim=1)
        combined_conv = self.conv_gates(combined)
        gamma, beta = torch.split(combined_conv, self.hidden_dim, dim=1)
        reset_gate = torch.sigmoid(gamma)
        update_gate = torch.sigmoid(beta)

        combined = torch.cat([input_tensor, reset_gate*h_cur], dim=1)
        cc_cnm = self.conv_can(combined)
        cnm = torch.tanh(cc_cnm)

        h_next = (1 - update_gate) * h_cur + update_gate * cnm
        return h_next


class convGRU(nn.Module):  # 输入是五维(batchsize,timesteps,channel,height,weight),输出是俩list
    def __init__(self, input_size, input_dim, hidden_dim, kernel_size, num_layers,
                 dtype=torch.cuda.FloatTensor, batch_first=True, bias=True, return_all_layers=False):
        """
        :param input_size: (int, int)
            Height and width of input tensor as (height, width).
        :param input_dim: int e.g. 256
            Number of channels of input tensor.
        :param hidden_dim: int e.g. 1024
            Number of channels of hidden state.
        :param kernel_size: (int, int)
            Size of the convolutional kernel.
        :param num_layers: int
            Number of ConvLSTM layers
        :param dtype: torch.cuda.FloatTensor or torch.FloatTensor
            Whether or not to use cuda.
        :param alexnet_path: str
            pretrained alexnet parameters
        :param batch_first: bool
            if the first position of array is batch or not
        :param bias: bool
            Whether or not to add the bias.
        :param return_all_layers: bool
            if return hidden and cell states for all layers
        """
        super(convGRU, self).__init__()

        # Make sure that both `kernel_size` and `hidden_dim` are lists having len == num_layers
        kernel_size = self._extend_for_multilayer(kernel_size, num_layers)
        hidden_dim = self._extend_for_multilayer(hidden_dim, num_layers)
        if not len(kernel_size) == len(hidden_dim) == num_layers:
            raise ValueError('Inconsistent list length.')

        self.height, self.width = input_size
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.kernel_size = kernel_size
        self.dtype = dtype
        self.num_layers = num_layers
        self.batch_first = batch_first
        self.bias = bias
        self.return_all_layers = return_all_layers

        cell_list = []
        for i in range(0, self.num_layers):
            cur_input_dim = input_dim if i == 0 else hidden_dim[i - 1]
            cell_list.append(convGRUCell(input_size=(self.height, self.width),
                                         input_dim=cur_input_dim,
                                         hidden_dim=self.hidden_dim[i],
                                         kernel_size=self.kernel_size[i],
                                         bias=self.bias,
                                         dtype=self.dtype))

        # convert python list to pytorch module
        self.cell_list = nn.ModuleList(cell_list)

    def forward(self, input_tensor, hidden_state=None):
        """
        :param input_tensor: (b, t, c, h, w) or (t,b,c,h,w) depends on if batch first or not
            extracted features from alexnet
        :param hidden_state:
        :return: layer_output_list, last_state_list
        """
        if not self.batch_first:
            # (t, b, c, h, w) -> (b, t, c, h, w)
            input_tensor = input_tensor.permute(1, 0, 2, 3, 4)

        # Implement stateful ConvLSTM
        if hidden_state is not None:
            raise NotImplementedError()
        else:
            # hidden_state被初始化为num_layers个形状为[batchsize,hidden_dim,h,w]的矩阵
            hidden_state = self._init_hidden(batch_size=input_tensor.size(0))

        layer_output_list = []
        last_state_list = []

        seq_len = input_tensor.size(1)  # timesteps,这里就是8帧图片
        cur_layer_input = input_tensor

        # 每个cell都产生timestep(seq_len)个隐藏状态存放在output_inner里
        for layer_idx in range(self.num_layers):
            h = hidden_state[layer_idx]  # 每个cell输入的初始隐藏状态
            output_inner = []
            # timestep(seq_len)个图片都要按顺序经过这个cell的处理，都产生相应的隐藏状态存在output_inner里
            for t in range(seq_len):
                # input current hidden and cell state then compute the next hidden and cell state through ConvLSTMCell forward function
                h = self.cell_list[layer_idx](input_tensor=cur_layer_input[:, t, :, :, :],  # (b,t,c,h,w)
                                              h_cur=h)
                output_inner.append(h)

            layer_output = torch.stack(output_inner, dim=1)
            # 如果有多个cell的话，下个cell的输入数据就是上个cell的产生的timestep个隐藏状态的堆叠
            cur_layer_input = layer_output

            # 存放num_layers个cell的所有输出隐藏状态，长度为num_layers,每个元素是形状为[batchsize,timestep,hidden_dim,h,w]的tensor，代表batchsize*timestep个隐藏状态
            layer_output_list.append(layer_output)
            # last_state_list.append([h])
            # 存放num_layers个cell的所有输出隐藏状态中的最后一个时间步的隐藏状态,长度为num_layers,每个元素是形状为[batchsize,hidden_dim,h,w]的tensor，代表batchsize个隐藏状态
            last_state_list.append(h)
        if not self.return_all_layers:  # 只返回最后一个cell的  timestep个隐藏状态和最后一个隐藏状态
            layer_output_list = layer_output_list[-1:]
            last_state_list = last_state_list[-1:]

        return layer_output_list, last_state_list

    def _init_hidden(self, batch_size):
        init_states = []
        for i in range(self.num_layers):
            init_states.append(self.cell_list[i].init_hidden(batch_size))
        return init_states

    @staticmethod
    def _check_kernel_size_consistency(kernel_size):
        if not (isinstance(kernel_size, tuple) or
                (isinstance(kernel_size, list) and all([isinstance(elem, tuple) for elem in kernel_size]))):
            raise ValueError('`kernel_size` must be tuple or list of tuples')

    @staticmethod
    def _extend_for_multilayer(param, num_layers):
        if not isinstance(param, list):
            param = [param] * num_layers
        return param


# 输出是个list  list里面元素形状是[batch_size,hidden_channels,h,w]
class Non_local_convGRU(nn.Module):
    def __init__(self, h_w, in_channels, out_channels, kernel_sizes=3, n_layers=1):
        super().__init__()
        self.height, self.weight = h_w
        self.non_local_block = NONLocalBlock2D(in_channels)
        self.convgru = convGRU(h_w, in_channels//8,
                               out_channels, (kernel_sizes, kernel_sizes), 1)

    def forward(self, X):  # 注意ConvGRU输入是五维(batchsize,timesteps,in_channels,height,weight)
        X = self.non_local_block(X)
        bs = X.size(0)
        channels = X.size(1)
        X = X.view(bs, 8, channels//8, self.height, self.weight)  # 改成五维模式
        layer_output_list, last_state_list = self.convgru(X)
        # last_state_list[-1]代表只要最后一个grucell的最后一个隐藏状态(虽然我本来也只用了一个cell)
        return last_state_list[-1]


# 输出是个list  list里面元素形状是[batch_size,hidden_channels,h,w]
class Non_local_convGRU3d(nn.Module):
    def __init__(self, h_w, in_channels, out_channels, kernel_sizes=3, n_layers=1):
        super().__init__()
        self.height, self.weight = h_w
        self.non_local_block = NONLocalBlock3D(in_channels)
        # self.convgru=convGRU(h_w,in_channels//8,out_channels,(kernel_sizes,kernel_sizes),1)
        self.convgru = convGRU(
            h_w, in_channels, out_channels, (kernel_sizes, kernel_sizes), 1)

    def forward(self, X):  # 注意ConvGRU输入是五维(batchsize,timesteps,in_channels,height,weight)
        X = self.non_local_block(X)
        bs = X.size(0)
        X = X.permute(0, 2, 1, 3, 4)  # (b,c,t,h,w)-->(b,t,c,h,w)
        layer_output_list, last_state_list = self.convgru(X)
        # last_state_list[-1]代表只要最后一个grucell的最后一个隐藏状态(虽然我本来也只用了一个cell)
        new_frame = last_state_list[-1]
        return torch.unsqueeze(new_frame, 2)


class ResNet(nn.Module):

    def __init__(self,
                 block,
                 layers,
                 n_input_channels=3,
                 conv1_t_size=7,  # 第一个cnn的kernel size
                 conv1_t_stride=1,  # 第一个cnn的时序stride
                 no_max_pool=True,
                 shortcut_type='B',
                 n_classes_y=2,
                 n_classes_z=4,
                 n_features=128,
                 m=0.999,
                 K=128):  # 对比学习队列长度
        super().__init__()
        self.K = K  # 队列长度为K
        self.m = m
        self.no_max_pool = no_max_pool

        self.encoderlist = [64, 128, 256, 512]
        self.prelist = [128, 256, 512]
        self.decoderlist = [3, 64, 128, 256]
        self.encoderlayers = [3, 4, 6]
        self.decoderlayers = [3, 4, 6]
        self.conv1 = nn.Conv3d(n_input_channels,  # 输入通道数3
                               self.encoderlist[0],
                               kernel_size=(conv1_t_size, 7, 7),
                               stride=(conv1_t_stride, 1, 1),
                               padding=(conv1_t_size // 2, 3, 3),
                               bias=False)
        self.bn1 = nn.BatchNorm3d(self.encoderlist[0])
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool3d(
            kernel_size=3, stride=2, padding=1)  # 注意stride默认为2
        self.encoder1 = self._make_layer(block,
                                         self.encoderlist[0],  # 64
                                         self.encoderlist[1],  # 128
                                         self.encoderlayers[0],  # 块数为3
                                         shortcut_type,
                                         stride=2)
        self.encoder2 = self._make_layer(block,
                                         self.encoderlist[1],
                                         # 传入时：通道数128，此时self.inplanes 256
                                         self.encoderlist[2],
                                         self.encoderlayers[1],  # 块数为4
                                         shortcut_type,
                                         stride=2)
        self.encoder3 = self._make_layer(block,
                                         self.encoderlist[2],
                                         self.encoderlist[3],  # 通道数256
                                         self.encoderlayers[2],  # 块数为6
                                         shortcut_type,
                                         stride=2)

        # gru换成residual3d
        self.pre1 = NOGru(self.encoderlist[1], self.prelist[0], 4)
        self.pre2 = NOGru(self.encoderlist[2], self.prelist[1], 2)
        self.pre3 = NOGru(self.encoderlist[3], self.prelist[2], 1)

        self.decoder3 = self._make_layer(block,
                                         self.prelist[2],
                                         self.decoderlist[3],  # 通道数
                                         self.decoderlayers[2],  # 块数
                                         shortcut_type)
        self.up3 = nn.Upsample(scale_factor=(1, 2, 2))

        self.decoder2 = self._make_layer(block,
                                         self.prelist[1]+self.decoderlist[3],
                                         self.decoderlist[2],  # 通道数
                                         self.decoderlayers[1],  # 块
                                         shortcut_type)
        self.up2 = nn.Upsample(scale_factor=(1, 2, 2))
        self.decoder1 = self._make_layer(block,
                                         self.prelist[0]+self.decoderlist[2],
                                         self.decoderlist[1],  # 通道数
                                         self.decoderlayers[0],  # 块数
                                         shortcut_type)
        self.up1 = nn.Upsample(scale_factor=(1, 2, 2))
        self.cnn2 = nn.Conv3d(self.decoderlist[1],
                              self.decoderlist[0],
                              kernel_size=(7, 7, 7),
                              stride=(1, 1, 1),
                              padding=(3, 3, 3),
                              bias=False)

        self.avgpool_y = nn.AdaptiveAvgPool3d((1, 1, 1))
        self.fc_y = nn.Linear(self.encoderlist[3], n_classes_y)
        self.avgpool_z = nn.AdaptiveAvgPool3d((1, 1, 1))
        self.fc_z = nn.Linear(self.encoderlist[3], n_classes_z)

        # 下面是projection head

        self.avgpool_pro1 = nn.AdaptiveAvgPool3d((1, 1, 1))
        self.mlp1 = nn.Sequential(
            nn.Linear(self.encoderlist[3], 2*n_features),
            nn.ReLU(),
            nn.Linear(2*n_features, n_features),
        )

        self.avgpool_pro2 = nn.AdaptiveAvgPool3d((1, 1, 1))
        self.mlp2 = nn.Sequential(
            nn.Linear(self.encoderlist[3], 2*n_features),
            nn.ReLU(),
            nn.Linear(2*n_features, n_features),
        )

        for m in self.modules():
            if isinstance(m, nn.Conv3d):
                nn.init.kaiming_normal_(m.weight,
                                        mode='fan_out',
                                        nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm3d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)

        for param_1, param_2 in zip(self.avgpool_pro1.parameters(), self.avgpool_pro2.parameters()):
            param_2.data.copy_(param_1.data)  # initialize
            param_2.requires_grad = False  # not update by gradient

        for param_1, param_2 in zip(self.mlp1.parameters(), self.mlp2.parameters()):
            param_2.data.copy_(param_1.data)  # initialize
            param_2.requires_grad = False  # not update by gradient

        # create the queue
        self.register_buffer("queue", torch.randn(128, K))  # 队列
        self.queue = nn.functional.normalize(self.queue, dim=0)
        self.register_buffer("queue_ptr", torch.zeros(
            1, dtype=torch.long))  # 队列指针

    def _downsample_basic_block(self, x, planes, stride):
        out = F.avg_pool3d(x, kernel_size=1, stride=stride)
        zero_pads = torch.zeros(out.size(0), planes - out.size(1), out.size(2),
                                out.size(3), out.size(4))
        if isinstance(out.data, torch.cuda.FloatTensor):
            zero_pads = zero_pads.cuda()

        out = torch.cat([out.data, zero_pads], dim=1)

        return out

    # layer1后self.in_planes从64变成了64*4=256,输出变成了256 layer2后self.in_planes从256变成了128*4=512，输出变成了512
    def _make_layer(self, block, in_planes, out_planes, blocks, shortcut_type, stride=1):
        downsample = None  # layer3后self.in_planes从512变成了256*4=1024，输出变成了1024 ,layer4后self.in_planes从2048变成了512*4=2048，输出变成了2048
        if stride != 1 or out_planes != in_planes:
            if shortcut_type == 'A':
                downsample = partial(self._downsample_basic_block,
                                     planes=planes,
                                     stride=stride)
            else:
                downsample = nn.Sequential(
                    conv1x1x1(in_planes, out_planes, stride),
                    nn.BatchNorm3d(out_planes))

        layers = []
        layers.append(
            block(in_planes=in_planes,
                  planes=out_planes,
                  stride=stride,
                  downsample=downsample))
        for i in range(1, blocks):  # 块数
            layers.append(block(out_planes, out_planes))

        return nn.Sequential(*layers)

    @torch.no_grad()
    def _momentum_update_key_encoder(self):
        """
        Momentum update of the  encoder 2
        """
        for param_1, param_2 in zip(self.avgpool_pro1.parameters(), self.avgpool_pro2.parameters()):
            param_2.data = param_2.data * self.m + param_1.data * (1. - self.m)
        for param_1, param_2 in zip(self.mlp1.parameters(), self.mlp2.parameters()):
            param_2.data = param_2.data * self.m + param_1.data * (1. - self.m)

    def forward(self, x, evaluate_bool):
        # y,label_y=reverse_batch(x)
        y, label_y = shuffle_batch(x, evaluate_bool)
        z, label_z = rotate_batch(x, evaluate_bool)

        x = self.relu(self.bn1(self.conv1(x)))
        y = self.relu(self.bn1(self.conv1(y)))
        z = self.relu(self.bn1(self.conv1(z)))
        # s = self.relu(self.bn1(self.conv1(s)))

        # print("x,y的梯度类型是",x.requires_grad,y.requires_grad)
        if not self.no_max_pool:
            x = self.maxpool(x)
            y = self.maxpool(y)
            z = self.maxpool(z)
            # s = self.maxpool(s)

        x1 = self.encoder1(x)
        x2 = self.encoder2(x1)
        x3 = self.encoder3(x2)
        y = self.encoder3(self.encoder2(self.encoder1(y)))
        z = self.encoder3(self.encoder2(self.encoder1(z)))
        # s=self.encoder3(self.encoder2(self.encoder1(s)))

        # print("x1,x2,x3形状",x1.shape,x2.shape,x3.shape)
        x1 = self.pre1(x1)
        x2 = self.pre2(x2)
        x3 = self.pre3(x3)

        x3 = self.up3(self.decoder3(x3))
        x2 = self.up2(self.decoder2(torch.cat([x2, x3], dim=1)))
        x1 = self.up1(self.decoder1(torch.cat([x1, x2], dim=1)))

        x = self.cnn2(x1)
        x = torch.squeeze(x, 2)

        y_features = self.avgpool_pro1(y)
        y_features = self.mlp1(y_features.view(
            y_features.size(0), -1))  # 128个特征
        y_features = nn.functional.normalize(y_features, dim=1)  # L2正则化

        with torch.no_grad():  # no gradient to encoder 2(k)
            self._momentum_update_key_encoder()  # update the key encoder
            z_features = self.avgpool_pro2(z)
            z_features = self.mlp2(z_features.view(
                z_features.size(0), -1))  # 128个特征
            z_features = nn.functional.normalize(z_features, dim=1)

        y = self.avgpool_y(y)
        z = self.avgpool_z(z)

        y = y.view(y.size(0), -1)
        y = nn.functional.normalize(y, dim=1)  # L2正则化
        z = z.view(z.size(0), -1)
        z = nn.functional.normalize(z, dim=1)

        y = self.fc_y(y)
        z = self.fc_z(z)

        return x, y, label_y, z, label_z, y_features, z_features  # 第九帧,俩任务


def generate_model(model_depth, **kwargs):
    assert model_depth in [10, 18, 34, 50, 101, 152, 200]

    if model_depth == 10:  # 最终选用这个
        model = ResNet(BasicBlock, [1, 1, 1, 1], **kwargs)
    elif model_depth == 18:
        model = ResNet(BasicBlock, [2, 2, 2, 2], **kwargs)
    elif model_depth == 34:
        model = ResNet(BasicBlock, [3, 4, 6, 3], **kwargs)
    elif model_depth == 50:
        model = ResNet(Bottleneck, [3, 4, 6, 3], **kwargs)
    elif model_depth == 101:
        model = ResNet(Bottleneck, [3, 4, 23, 3],  **kwargs)
    elif model_depth == 152:
        model = ResNet(Bottleneck, [3, 8, 36, 3], **kwargs)
    elif model_depth == 200:
        model = ResNet(Bottleneck, [3, 24, 36, 3],  **kwargs)

    return model


if __name__ == '__main__':
    x = torch.ones([1, 3, 8, 256, 256]).cuda()
    print('x原始tensor：\n', x.shape, x.device)
    my_resnet = generate_model(10)
    my_resnet = nn.DataParallel(my_resnet).cuda()

    x, y, label_y, z, label_z = my_resnet(x)
    print("x,y,label_y,z,label_z的形状是", x.shape, y.shape,
          label_y.shape, z.shape, label_z.shape)
    print("x,y,z的设备是", x.device, y.device, z.device)
    print("x,y,label_y,z,label_z是", x, y, label_y, z, label_z)
    loss = nn.CrossE
